"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Link2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import Logo from "@/components/logo"
import BackButton from "@/components/back-button"
import WorkItem from "@/components/work-item"

// Sample user works data
const userWorks = [
  {
    id: "1",
    title: "paris project",
    role: "filmmaker",
    image: "/images/paris-project.jpg",
  },
  {
    id: "2",
    title: "postcards from barcelona",
    role: "filmmaker",
    image: "/images/barcelona.jpg",
  },
  {
    id: "3",
    title: "tanzania",
    role: "filmmaker",
    image: "/images/tanzania.jpg",
  },
  {
    id: "4",
    title: "edit process",
    role: "filmmaker",
    image: "/images/edit-process.jpg",
  },
]

export default function ApplyJob({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [application, setApplication] = useState("")
  const [showWorkSelector, setShowWorkSelector] = useState(false)
  const [selectedWorks, setSelectedWorks] = useState<string[]>([])

  // In a real app, we would fetch job details based on the ID
  const jobDetails = {
    id: params.id,
    role: "filmmaker",
    location: "amsterdam",
    date: "16/04",
  }

  const handleWorkSelection = (id: string) => {
    setSelectedWorks((prev) => (prev.includes(id) ? prev.filter((workId) => workId !== id) : [...prev, id]))
  }

  const handleCancel = () => {
    router.back()
  }

  const handleSubmit = () => {
    // In a real app, we would submit the application data to the server
    console.log({
      jobId: params.id,
      application,
      selectedWorks,
    })

    // Navigate back to the discovery page
    router.push("/")
  }

  return (
    <div className="pb-32">
      <div className="flex items-center justify-between p-4">
        <BackButton />
        <Logo />
        <div className="w-10"></div> {/* Spacer for alignment */}
      </div>

      <div className="p-4">
        <h1 className="text-3xl font-medium mb-2">
          {jobDetails.role} <span className="text-muted-foreground">needed in</span> {jobDetails.location}{" "}
          <span className="text-muted-foreground">on</span> {jobDetails.date}
        </h1>

        <h2 className="text-2xl mb-6">application</h2>

        <div className="space-y-6">
          <div>
            <Textarea
              placeholder="explain why you would be a good fit and include any questions you may have"
              className="min-h-[200px] bg-secondary border-none rounded-3xl p-4"
              value={application}
              onChange={(e) => setApplication(e.target.value)}
            />
          </div>

          <div>
            <h3 className="text-xl mb-4">upload additional work</h3>
            <div
              className="bg-secondary rounded-3xl p-4 flex items-center justify-between cursor-pointer"
              onClick={() => setShowWorkSelector(!showWorkSelector)}
            >
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined">grid_view</span>
                <span>select work</span>
              </div>
              <span className="material-symbols-outlined">{showWorkSelector ? "expand_less" : "expand_more"}</span>
            </div>

            {showWorkSelector && (
              <div className="mt-4 grid grid-cols-2 gap-4">
                {userWorks.map((work) => (
                  <WorkItem
                    key={work.id}
                    id={work.id}
                    title={work.title}
                    role={work.role}
                    image={work.image}
                    selected={selectedWorks.includes(work.id)}
                    onSelect={handleWorkSelection}
                  />
                ))}
              </div>
            )}

            <div className="mt-4 flex items-center">
              <div className="text-xl mr-4">or</div>
              <Button variant="outline" className="rounded-full flex items-center gap-2">
                <Link2 className="h-4 w-4" />
                enter url
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto border-t bg-background p-4 flex items-center justify-between">
        <Button variant="outline" className="rounded-full px-8 py-6" onClick={handleCancel}>
          cancel
        </Button>
        <Button className="rounded-full px-8 py-6" onClick={handleSubmit}>
          submit application
        </Button>
      </div>
    </div>
  )
}

