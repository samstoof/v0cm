"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import Logo from "@/components/logo"
import BackButton from "@/components/back-button"

// Creative leads data
const creativeLeads = [
  {
    id: "1",
    name: "daiki shino",
    avatar: "/images/daiki-shino.jpg",
    role: "creative lead",
    profile: "/profile/daiki.shino",
  },
  {
    id: "2",
    name: "bibi-jane angelica",
    avatar: "/images/bibi-jane.jpg",
    role: "creative lead",
    profile: "/profile/bibi.jane",
  },
  {
    id: "3",
    name: "alex thompson",
    avatar: "/images/creative-lead-1.jpg",
    role: "creative lead",
    profile: "/profile/alex.thompson",
  },
  {
    id: "4",
    name: "maria rodriguez",
    avatar: "/images/creative-lead-2.jpg",
    role: "creative lead",
    profile: "/profile/maria.rodriguez",
  },
  {
    id: "5",
    name: "james wilson",
    avatar: "/images/creative-lead-3.jpg",
    role: "creative lead",
    profile: "/profile/james.wilson",
  },
]

export default function JobDetail({ params }: { params: { id: string } }) {
  // In a real app, we would fetch job details based on the ID
  const jobDetails = {
    id: params.id,
    coverImage:
      params.id === "1"
        ? "/images/make-movies-friends.jpg"
        : `/images/job-cover-${Math.min(Number.parseInt(params.id), 5)}.jpg`,
    title: "make movies with friends.",
    director: "daiki shino",
    avatar: "/images/daiki-shino.jpg",
    role: "filmmaker",
    location: "amsterdam",
    date: "16/04",
    closesIn: "2 days",
    slotsLeft: "1",
    budget: "€1.500/day",
    type: "gig",
    description:
      "creatormate is looking for a filmmaker to shoot an episode of their youtube documentary series. this is all about what it's really like to raise money: they'll visit other founders in amsterdam and walk through their pitch decks, giving the audience a behind-the-scenes look into the nitty-gritty of securing funds.",
    tags: ["filming", "setup lights", "treatment", "interactive"],
    requirements: [
      "experience docu style filmmaking",
      "one year of video editing experience",
      "one year of video editing experience",
    ],
    links: [
      { platform: "x.com", handle: "trycreatormate" },
      { platform: "wikipedia", handle: "trycreatormate" },
      { platform: "linkedin", handle: "trycreatormate" },
    ],
    deliverables: [
      { type: "video", name: "video 1" },
      { type: "video", name: "video 1" },
      { type: "video", name: "video 1" },
    ],
    client: {
      name: "creatormate",
      headquarters: "amsterdam based",
      employees: "10-30",
      industry: "tech/data",
    },
    creativeLead:
      creativeLeads[
        params.id === "1" ? 0 : Math.min(Number.parseInt(params.id) % creativeLeads.length, creativeLeads.length - 1)
      ],
  }

  return (
    <div className="pb-32">
      <div className="flex items-center justify-between p-4">
        <BackButton />
        <Logo />
        <div className="w-10"></div> {/* Spacer for alignment */}
      </div>

      <div className="relative">
        <div className="w-full h-64">
          <Image
            src={jobDetails.coverImage || "/placeholder.svg"}
            alt={jobDetails.title}
            width={800}
            height={500}
            className="w-full h-full object-cover"
            priority
          />
          {params.id === "1" && (
            <div className="absolute inset-0 flex items-center justify-center">
              <h1 className="text-4xl font-bold text-white text-center">make movies with friends.</h1>
            </div>
          )}
        </div>
        <div className="absolute bottom-0 left-0 right-0 p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-full overflow-hidden bg-white">
              <Image
                src={jobDetails.avatar || "/placeholder.svg"}
                alt={jobDetails.director}
                width={80}
                height={80}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="text-white">
              <div className="text-sm">director</div>
              <div className="font-medium">{jobDetails.director}</div>
            </div>
          </div>
          <button className="text-white">
            <span className="material-symbols-outlined">share</span>
          </button>
        </div>
      </div>

      <div className="p-6">
        <div className="mb-6">
          <h2 className="text-3xl font-medium">
            {jobDetails.role} <span className="text-muted-foreground">needed in</span> {jobDetails.location}{" "}
            <span className="text-muted-foreground">on</span> {jobDetails.date}
          </h2>
        </div>

        <div className="flex gap-4 mb-6">
          <div className="bg-secondary rounded-full px-4 py-2 text-sm">closes in {jobDetails.closesIn}</div>
          <div className="bg-secondary rounded-full px-4 py-2 text-sm">{jobDetails.slotsLeft} slots left</div>
        </div>

        <div className="mb-8">
          <h3 className="text-2xl font-medium mb-4">about the job</h3>
          <p className="text-lg leading-relaxed mb-6">{jobDetails.description}</p>

          <div className="flex flex-wrap gap-2 mb-6">
            {jobDetails.tags.map((tag, index) => (
              <div key={index} className="border rounded-full px-4 py-2">
                {tag}
              </div>
            ))}
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-2xl font-medium mb-4">requirements</h3>
          <ul className="space-y-2">
            {jobDetails.requirements.map((req, index) => (
              <li key={index} className="flex items-start gap-2">
                <span className="text-lg">•</span>
                <span className="text-lg">{req}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="mb-8">
          <div className="grid grid-cols-3 gap-2 mb-6">
            {jobDetails.links.map((link, index) => (
              <div key={index} className="flex flex-col items-center">
                <div className="flex justify-center mb-2">
                  <span className="material-symbols-outlined">link</span>
                </div>
                <div className="text-sm">{link.platform}</div>
                <div className="text-xs text-muted-foreground truncate">{link.handle}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-2xl font-medium mb-4">deliverables</h3>
          <div className="grid grid-cols-3 gap-2">
            {jobDetails.deliverables.map((deliverable, index) => (
              <div key={index} className="flex flex-col items-center">
                <div className="flex justify-center mb-2">
                  <span className="material-symbols-outlined">videocam</span>
                </div>
                <div className="text-sm">{deliverable.name}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-2xl font-medium mb-4">about the client</h3>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center">
                <span className="text-sm font-medium">{jobDetails.client.name.charAt(0).toUpperCase()}</span>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">client</div>
                <div className="font-medium">{jobDetails.client.name}</div>
              </div>
            </div>

            <div>
              <div className="text-sm text-muted-foreground">headquarters</div>
              <div>{jobDetails.client.headquarters}</div>
            </div>

            <div>
              <div className="text-sm text-muted-foreground">employees</div>
              <div>{jobDetails.client.employees}</div>
            </div>

            <div>
              <div className="text-sm text-muted-foreground">industry</div>
              <div>{jobDetails.client.industry}</div>
            </div>

            <div className="flex gap-4 pt-2">
              <Button variant="outline" className="rounded-full px-4">
                <span className="material-symbols-outlined mr-2 text-sm">language</span>
                website
              </Button>
              <Button variant="outline" className="rounded-full px-4">
                <span className="material-symbols-outlined mr-2 text-sm">photo_camera</span>
                instagram
              </Button>
              <Button variant="outline" className="rounded-full px-4">
                <span className="material-symbols-outlined mr-2 text-sm">smart_display</span>
                youtube
              </Button>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-2xl font-medium mb-4">about the creative lead</h3>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full overflow-hidden">
                <Image
                  src={jobDetails.creativeLead.avatar || "/placeholder.svg"}
                  alt={jobDetails.creativeLead.name}
                  width={80}
                  height={80}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <div className="text-sm text-muted-foreground">{jobDetails.creativeLead.role}</div>
                <div className="font-medium">{jobDetails.creativeLead.name}</div>
              </div>
            </div>
            <Link href={jobDetails.creativeLead.profile}>
              <Button variant="outline" className="rounded-full px-4">
                view profile
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto border-t bg-background p-4 flex items-center justify-between">
        <div>
          <div className="font-bold text-xl">{jobDetails.budget}</div>
          <div className="text-muted-foreground">{jobDetails.type}</div>
        </div>
        <Link href={`/jobs/${params.id}/apply`}>
          <Button className="rounded-full px-8 py-6">apply</Button>
        </Link>
      </div>
    </div>
  )
}

