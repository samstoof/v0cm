"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import Logo from "@/components/logo"
import BottomNavigation from "@/components/bottom-navigation"
import TabButton from "@/components/tab-button"

// Sample job data
const myJobs = [
  {
    id: "1",
    thumbnail: "/images/make-movies-friends.jpg",
    role: "filmmaker",
    location: "amsterdam",
    date: "16/04",
    appliedDaysAgo: 8,
    status: "pending",
    category: "pending",
  },
  {
    id: "2",
    thumbnail: "/images/job-cover-2.jpg",
    role: "video editor",
    location: "amsterdam",
    date: "15/03",
    appliedDaysAgo: 3,
    status: "pending",
    category: "pending",
  },
  {
    id: "3",
    thumbnail: "/images/job-cover-3.jpg",
    role: "photographer",
    location: "utrecht",
    date: "20/01",
    appliedDaysAgo: 30,
    status: "archived",
    category: "archived",
  },
  {
    id: "4",
    thumbnail: "/images/job-cover-4.jpg",
    role: "sound designer",
    location: "den haag",
    date: "05/02",
    appliedDaysAgo: 15,
    status: "pending",
    category: "pending",
  },
  {
    id: "5",
    thumbnail: "/images/job-cover-5.jpg",
    role: "drone operator",
    location: "eindhoven",
    date: "10/01",
    appliedDaysAgo: 45,
    status: "archived",
    category: "archived",
  },
  {
    id: "6",
    thumbnail: "/images/job-cover-1.jpg",
    role: "camera operator",
    location: "rotterdam",
    date: "12/05",
    appliedDaysAgo: 4,
    status: "cancelled",
    category: "cancelled",
  },
  {
    id: "7",
    thumbnail: "/images/job-cover-2.jpg",
    role: "lighting technician",
    location: "eindhoven",
    date: "05/05",
    appliedDaysAgo: 5,
    status: "cancelled",
    category: "cancelled",
  },
  {
    id: "8",
    thumbnail: "/images/job-cover-3.jpg",
    role: "drone operator",
    location: "groningen",
    date: "10/05",
    appliedDaysAgo: 6,
    status: "cancelled",
    category: "cancelled",
  },
]

type TabType = "pending" | "cancelled" | "archived"

export default function MyJobs() {
  const [activeTab, setActiveTab] = useState<TabType>("pending")

  const filteredJobs = myJobs.filter((job) => job.category === activeTab)

  return (
    <div className="pb-28">
      <Logo />

      <div className="px-4 pt-8 pb-4">
        <h2 className="text-4xl font-bold mb-6">my jobs</h2>

        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          <TabButton active={activeTab === "pending"} onClick={() => setActiveTab("pending")}>
            pending
          </TabButton>
          <TabButton active={activeTab === "cancelled"} onClick={() => setActiveTab("cancelled")}>
            cancelled
          </TabButton>
          <TabButton active={activeTab === "archived"} onClick={() => setActiveTab("archived")}>
            archive
          </TabButton>
        </div>

        <div className="space-y-4">
          {filteredJobs.length > 0 ? (
            filteredJobs.map((job) => (
              <Link key={job.id} href={`/my-jobs/${job.id}`} className="block">
                <div className="border rounded-3xl p-4">
                  <div className="mb-2">applied {job.appliedDaysAgo} days ago</div>

                  <div className="flex items-center gap-3 mb-4">
                    <div className="h-20 w-20 rounded-md overflow-hidden">
                      <Image
                        src={job.thumbnail || "/placeholder.svg"}
                        alt={`${job.role} job thumbnail`}
                        width={200}
                        height={200}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="text-xl font-medium">
                        {job.role} <span className="text-muted-foreground">needed in</span> {job.location}{" "}
                        <span className="text-muted-foreground">on</span> {job.date}
                      </div>
                    </div>
                    <div className="ml-auto">
                      <span className="material-symbols-outlined">north_east</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {job.status === "cancelled" && (
                        <span className="material-symbols-outlined text-muted-foreground">close</span>
                      )}
                      {job.status === "pending" && (
                        <span className="material-symbols-outlined text-muted-foreground">schedule</span>
                      )}
                      {job.status === "archived" && (
                        <span className="material-symbols-outlined text-muted-foreground">archive</span>
                      )}
                    </div>
                    <div
                      className={`${
                        job.status === "cancelled"
                          ? "bg-[#FFF2F2] text-[#D92D20]"
                          : job.status === "pending"
                            ? "bg-[#FFF8E7] text-[#B54708]"
                            : "bg-gray-100 text-gray-800"
                      } rounded-full px-4 py-1`}
                    >
                      status: {job.status}
                    </div>
                    <div>
                      <span className="material-symbols-outlined">chevron_right</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground text-lg">no {activeTab} jobs found</p>
            </div>
          )}
        </div>
      </div>

      <BottomNavigation />
    </div>
  )
}

