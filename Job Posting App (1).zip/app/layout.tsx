import type React from "react"
import type { Metadata } from "next"
import { Figtree } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import SwipeContainer from "@/components/swipe-container"

const figtree = Figtree({
  subsets: ["latin"],
  variable: "--font-figtree",
})

export const metadata: Metadata = {
  title: "cm - job posting app",
  description: "find and apply for creative jobs",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <head>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
      </head>
      <body className={`${figtree.variable} font-sans lowercase`}>
        <ThemeProvider attribute="class" defaultTheme="light">
          <main className="min-h-screen max-w-md mx-auto bg-background">
            <SwipeContainer>{children}</SwipeContainer>
          </main>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'