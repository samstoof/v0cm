"use client"

import { useState } from "react"
import Link from "next/link"
import Logo from "@/components/logo"
import BottomNavigation from "@/components/bottom-navigation"
import { Button } from "@/components/ui/button"
import JobCard from "@/components/job-card"
import TabButton from "@/components/tab-button"
import SearchBar from "@/components/search-bar"

// Sample job data
const allJobs = [
  {
    id: "1",
    avatar: "/images/daiki-shino.jpg",
    director: "daiki shino",
    postedTime: "1 hr ago",
    role: "filmmaker",
    location: "amsterdam",
    date: "16/04",
    budget: "€1.500",
    category: "forYou",
  },
  {
    id: "2",
    avatar: "/images/bibi-jane.jpg",
    director: "bibi-jane angelica",
    postedTime: "1 day ago",
    role: "mixed media editor",
    company: "otrium",
    date: "20/04",
    location: "remote",
    budget: "€30/hr",
    category: "forYou",
  },
  {
    id: "3",
    avatar: "/images/bibi-jane.jpg",
    director: "bibi-jane angelica",
    postedTime: "1 day ago",
    role: "director photography",
    location: "almelo",
    date: "21/05",
    budget: "€2.000",
    category: "allJobs",
  },
  {
    id: "4",
    avatar: "/images/job-image-1.jpg",
    director: "alex thompson",
    postedTime: "2 days ago",
    role: "video editor",
    location: "utrecht",
    date: "25/04",
    budget: "€1.800",
    category: "allJobs",
  },
  {
    id: "5",
    avatar: "/images/job-image-2.jpg",
    director: "maria rodriguez",
    postedTime: "3 days ago",
    role: "sound designer",
    location: "den haag",
    date: "18/04",
    budget: "€1.200",
    category: "archived",
  },
  {
    id: "6",
    avatar: "/images/job-image-3.jpg",
    director: "jan de vries",
    postedTime: "4 days ago",
    role: "camera operator",
    location: "rotterdam",
    date: "12/05",
    budget: "€250/day",
    category: "archived",
  },
  {
    id: "7",
    avatar: "/images/job-image-4.jpg",
    director: "emma johnson",
    postedTime: "5 days ago",
    role: "lighting technician",
    location: "eindhoven",
    date: "05/05",
    budget: "€200/day",
    category: "forYou",
  },
  {
    id: "8",
    avatar: "/images/job-image-5.jpg",
    director: "lucas van den berg",
    postedTime: "6 days ago",
    role: "drone operator",
    location: "groningen",
    date: "10/05",
    budget: "€300/day",
    category: "allJobs",
  },
  // Additional job posts
  {
    id: "9",
    avatar: "/images/job-image-6.jpg",
    director: "sophie klein",
    postedTime: "2 days ago",
    role: "production assistant",
    location: "amsterdam",
    date: "28/04",
    budget: "€150/day",
    category: "forYou",
  },
  {
    id: "10",
    avatar: "/images/job-image-7.jpg",
    director: "thomas bakker",
    postedTime: "3 days ago",
    role: "colorist",
    location: "utrecht",
    date: "05/05",
    budget: "€45/hr",
    category: "allJobs",
  },
  {
    id: "11",
    avatar: "/images/job-image-8.jpg",
    director: "lisa de jong",
    postedTime: "1 day ago",
    role: "makeup artist",
    location: "rotterdam",
    date: "22/04",
    budget: "€180/day",
    category: "forYou",
  },
  {
    id: "12",
    avatar: "/images/job-image-1.jpg",
    director: "mark visser",
    postedTime: "4 days ago",
    role: "sound recordist",
    location: "den haag",
    date: "30/04",
    budget: "€220/day",
    category: "allJobs",
  },
  {
    id: "13",
    avatar: "/images/job-image-2.jpg",
    director: "anna peters",
    postedTime: "2 days ago",
    role: "set designer",
    location: "amsterdam",
    date: "15/05",
    budget: "€1.800",
    category: "archived",
  },
  {
    id: "14",
    avatar: "/images/job-image-3.jpg",
    director: "david smit",
    postedTime: "5 days ago",
    role: "storyboard artist",
    location: "eindhoven",
    date: "10/05",
    budget: "€35/hr",
    category: "forYou",
  },
  {
    id: "15",
    avatar: "/images/job-image-4.jpg",
    director: "julia vermeer",
    postedTime: "1 day ago",
    role: "vfx artist",
    location: "utrecht",
    date: "18/04",
    budget: "€40/hr",
    category: "allJobs",
  },
]

type TabType = "forYou" | "allJobs" | "archived"

export default function Home() {
  const [activeTab, setActiveTab] = useState<TabType>("forYou")
  const [searchQuery, setSearchQuery] = useState("")
  const [showFilter, setShowFilter] = useState(false)

  const handleSearch = (query: string) => {
    setSearchQuery(query)
  }

  const handleFilterClick = () => {
    setShowFilter(!showFilter)
  }

  const filteredJobs = allJobs.filter((job) => {
    // First filter by active tab
    if (job.category !== activeTab) {
      return false
    }

    // Then filter by search query if it exists
    if (searchQuery) {
      const searchLower = searchQuery.toLowerCase()
      return (
        job.role.toLowerCase().includes(searchLower) ||
        job.location.toLowerCase().includes(searchLower) ||
        job.director.toLowerCase().includes(searchLower) ||
        (job.company && job.company.toLowerCase().includes(searchLower))
      )
    }

    return true
  })

  return (
    <div className="pb-28">
      <Logo />

      <div className="px-4 pt-8 pb-4">
        <h2 className="text-4xl font-bold mb-6">discovery</h2>

        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          <TabButton active={activeTab === "forYou"} onClick={() => setActiveTab("forYou")}>
            for you
          </TabButton>
          <TabButton active={activeTab === "allJobs"} onClick={() => setActiveTab("allJobs")}>
            all jobs
          </TabButton>
          <TabButton active={activeTab === "archived"} onClick={() => setActiveTab("archived")}>
            archived
          </TabButton>
          <Link href="/filter">
            <Button variant="outline" className="rounded-full p-0 w-12 h-12">
              <span className="material-symbols-outlined">tune</span>
            </Button>
          </Link>
          <SearchBar onSearch={handleSearch} />
        </div>

        <div className="space-y-4">
          {filteredJobs.length > 0 ? (
            filteredJobs.map((job) => (
              <JobCard
                key={job.id}
                id={job.id}
                avatar={job.avatar}
                director={job.director}
                postedTime={job.postedTime}
                role={job.role}
                location={job.location}
                date={job.date}
                company={job.company}
                budget={job.budget}
              />
            ))
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground text-lg">no jobs found</p>
              {searchQuery && (
                <Button variant="outline" className="mt-4 rounded-full" onClick={() => setSearchQuery("")}>
                  clear search
                </Button>
              )}
            </div>
          )}
        </div>
      </div>

      <BottomNavigation />
    </div>
  )
}

