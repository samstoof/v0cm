"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import Logo from "@/components/logo"
import BackButton from "@/components/back-button"
import TabButton from "@/components/tab-button"

export default function FilterPage() {
  const router = useRouter()
  const [selectedRoles, setSelectedRoles] = useState<string[]>(["filmmaker"])
  const [selectedBudgetType, setSelectedBudgetType] = useState<string | null>(null)

  const handleRoleToggle = (role: string) => {
    setSelectedRoles((prev) => (prev.includes(role) ? prev.filter((r) => r !== role) : [...prev, role]))
  }

  const handleBudgetTypeSelect = (type: string) => {
    setSelectedBudgetType((prev) => (prev === type ? null : type))
  }

  const handleApplyFilters = () => {
    // In a real app, we would apply these filters to the job search
    console.log({
      roles: selectedRoles,
      budgetType: selectedBudgetType,
    })

    // Navigate back to the discovery page
    router.push("/")
  }

  return (
    <div className="pb-28">
      <div className="flex items-center justify-between p-4">
        <BackButton />
        <Logo />
        <div className="w-10"></div> {/* Spacer for alignment */}
      </div>

      <div className="px-4 pt-4 pb-4">
        <div className="space-y-8">
          <div>
            <h3 className="text-2xl mb-4">roles</h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="filmmaker"
                  checked={selectedRoles.includes("filmmaker")}
                  onCheckedChange={() => handleRoleToggle("filmmaker")}
                  className="h-6 w-6 rounded-sm border-2 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"
                />
                <label htmlFor="filmmaker" className="text-lg">
                  filmmaker (1)
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="editor"
                  checked={selectedRoles.includes("editor")}
                  onCheckedChange={() => handleRoleToggle("editor")}
                  className="h-6 w-6 rounded-sm border-2"
                />
                <label htmlFor="editor" className="text-lg">
                  editor (1)
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="director"
                  checked={selectedRoles.includes("director")}
                  onCheckedChange={() => handleRoleToggle("director")}
                  className="h-6 w-6 rounded-sm border-2"
                />
                <label htmlFor="director" className="text-lg">
                  director (1)
                </label>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-2xl mb-4">budget</h3>
            <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
              <TabButton active={selectedBudgetType === "daily"} onClick={() => handleBudgetTypeSelect("daily")}>
                daily rate
              </TabButton>
              <TabButton active={selectedBudgetType === "hourly"} onClick={() => handleBudgetTypeSelect("hourly")}>
                hourly
              </TabButton>
              <TabButton active={selectedBudgetType === "budget"} onClick={() => handleBudgetTypeSelect("budget")}>
                budget
              </TabButton>
            </div>
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto border-t bg-background p-4">
        <Button className="w-full rounded-full py-6 text-lg" onClick={handleApplyFilters}>
          apply filters
        </Button>
      </div>
    </div>
  )
}

