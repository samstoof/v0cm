"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Logo from "@/components/logo"
import BottomNavigation from "@/components/bottom-navigation"
import Link from "next/link"

export default function Settings() {
  const [editingField, setEditingField] = useState<string | null>(null)
  const [profileData, setProfileData] = useState({
    email: "olec.jaeger@gmail.com",
    password: "**********",
    phone: "06123456789",
    instagram: "@olec.jaeger",
  })
  const [tempValue, setTempValue] = useState("")

  const handleEditClick = (field: string) => {
    setEditingField(field)
    setTempValue(profileData[field as keyof typeof profileData])
  }

  const handleSave = () => {
    if (editingField) {
      setProfileData({
        ...profileData,
        [editingField]: tempValue,
      })
      setEditingField(null)
    }
  }

  const handleCancel = () => {
    setEditingField(null)
  }

  return (
    <div className="pb-28">
      <Logo />

      <div className="px-4 pt-8 pb-4">
        <h2 className="text-4xl font-bold mb-2">settings</h2>
        <p className="text-xl text-muted-foreground mb-8">oversee all your settings</p>

        <div className="space-y-8">
          <div>
            <h3 className="text-2xl mb-4">profile</h3>
            <Link href="/profile/olec.jaeger">
              <div className="border rounded-3xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="h-16 w-16 rounded-full overflow-hidden">
                    <Image
                      src="/images/olec-jaeger.jpg"
                      alt="Profile"
                      width={80}
                      height={80}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <div className="font-medium text-xl">olec jaeger</div>
                    <div className="text-muted-foreground">filmmaker</div>
                  </div>
                </div>
                <div>
                  <span className="material-symbols-outlined">north_east</span>
                </div>
              </div>
            </Link>
          </div>

          <div>
            <h3 className="text-2xl mb-4">email</h3>
            {editingField === "email" ? (
              <div className="flex items-center justify-between">
                <Input value={tempValue} onChange={(e) => setTempValue(e.target.value)} className="flex-1 mr-2" />
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleCancel}>
                    Cancel
                  </Button>
                  <Button size="sm" onClick={handleSave}>
                    Save
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div className="text-lg">{profileData.email}</div>
                <Button variant="ghost" size="icon" onClick={() => handleEditClick("email")}>
                  <span className="material-symbols-outlined">edit</span>
                </Button>
              </div>
            )}
          </div>

          <div>
            <h3 className="text-2xl mb-4">password</h3>
            {editingField === "password" ? (
              <div className="flex items-center justify-between">
                <Input
                  type="password"
                  value={tempValue}
                  onChange={(e) => setTempValue(e.target.value)}
                  className="flex-1 mr-2"
                />
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleCancel}>
                    Cancel
                  </Button>
                  <Button size="sm" onClick={handleSave}>
                    Save
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div className="text-lg">{profileData.password}</div>
                <Button variant="ghost" size="icon" onClick={() => handleEditClick("password")}>
                  <span className="material-symbols-outlined">edit</span>
                </Button>
              </div>
            )}
          </div>

          <div>
            <h3 className="text-2xl mb-4">phone number</h3>
            {editingField === "phone" ? (
              <div className="flex items-center justify-between">
                <Input value={tempValue} onChange={(e) => setTempValue(e.target.value)} className="flex-1 mr-2" />
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleCancel}>
                    Cancel
                  </Button>
                  <Button size="sm" onClick={handleSave}>
                    Save
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div className="text-lg">{profileData.phone}</div>
                <Button variant="ghost" size="icon" onClick={() => handleEditClick("phone")}>
                  <span className="material-symbols-outlined">edit</span>
                </Button>
              </div>
            )}
          </div>

          <div>
            <div className="flex items-center gap-2 mb-4">
              <span className="material-symbols-outlined">photo_camera</span>
              <h3 className="text-2xl">instagram (required)</h3>
            </div>
            {editingField === "instagram" ? (
              <div className="flex items-center justify-between">
                <Input value={tempValue} onChange={(e) => setTempValue(e.target.value)} className="flex-1 mr-2" />
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleCancel}>
                    Cancel
                  </Button>
                  <Button size="sm" onClick={handleSave}>
                    Save
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div className="text-lg">{profileData.instagram}</div>
                <Button variant="destructive" className="rounded-full bg-destructive text-destructive-foreground">
                  disconnect
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      <BottomNavigation />
    </div>
  )
}

