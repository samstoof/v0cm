"use client"

import Image from "next/image"
import Link from "next/link"
import BackButton from "@/components/back-button"
import Logo from "@/components/logo"
import BottomNavigation from "@/components/bottom-navigation"

export default function ProfileContactPage({ params }: { params: { username: string } }) {
  // In a real app, we would fetch user profile based on the username
  const profile = {
    username: params.username || "olec.jaeger",
    name: "olec jaeger",
    role: "filmmaker",
    location: "amsterdam, the netherlands",
    avatar: "/images/olec-jaeger.jpg",
    email: "olec.jaeger@gmail.com",
    phone: "06 12 34 56 78 9",
    website: "www.olecjaeger.com/",
    instagram: "olec.jaeger",
  }

  return (
    <div className="pb-28">
      <div className="flex items-center justify-between p-4">
        <BackButton />
        <Logo />
        <div className="w-10"></div> {/* Spacer for alignment */}
      </div>

      <div className="px-6 pt-8">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h1 className="text-4xl font-bold mb-1">{profile.name}</h1>
            <p className="text-xl text-foreground">{profile.role}</p>
          </div>
          <div className="h-20 w-20 rounded-full overflow-hidden">
            <Image
              src={profile.avatar || "/placeholder.svg"}
              alt={profile.name}
              width={200}
              height={200}
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        <div className="flex items-center gap-2 mb-8">
          <span className="material-symbols-outlined text-muted-foreground">location_on</span>
          <span className="text-lg">{profile.location}</span>
          <div className="ml-auto">
            <span className="material-symbols-outlined">share</span>
          </div>
        </div>

        <div className="border-b mb-12">
          <div className="flex justify-between">
            <Link href={`/profile/${profile.username}/work`} className="text-xl pb-4 px-4 text-muted-foreground">
              work
            </Link>
            <Link href={`/profile/${profile.username}/about`} className="text-xl pb-4 px-4 text-muted-foreground">
              about
            </Link>
            <Link
              href={`/profile/${profile.username}/contact`}
              className="text-xl pb-4 px-4 border-b-2 border-foreground font-medium"
            >
              contact
            </Link>
          </div>
        </div>

        <div className="mb-12">
          <h2 className="text-3xl font-bold mb-8">contact</h2>

          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <span className="material-symbols-outlined text-muted-foreground">mail</span>
              <span className="text-xl text-muted-foreground">{profile.email}</span>
            </div>

            <div className="flex items-center gap-4">
              <span className="material-symbols-outlined text-muted-foreground">call</span>
              <span className="text-xl text-muted-foreground">{profile.phone}</span>
            </div>

            <div className="flex items-center gap-4">
              <span className="material-symbols-outlined text-muted-foreground">language</span>
              <span className="text-xl text-muted-foreground">{profile.website}</span>
            </div>

            <div className="flex items-center gap-4">
              <span className="material-symbols-outlined text-muted-foreground">photo_camera</span>
              <span className="text-xl text-muted-foreground">{profile.instagram}</span>
            </div>
          </div>
        </div>
      </div>

      <BottomNavigation />
    </div>
  )
}

