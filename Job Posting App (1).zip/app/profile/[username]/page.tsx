import { redirect } from "next/navigation"

export default function ProfilePage({ params }: { params: { username: string } }) {
  // Redirect to the work tab by default
  redirect(`/profile/${params.username}/work`)
}

