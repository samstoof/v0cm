"use client"

import Image from "next/image"
import Link from "next/link"
import BackButton from "@/components/back-button"
import Logo from "@/components/logo"
import BottomNavigation from "@/components/bottom-navigation"

export default function ProfileAboutPage({ params }: { params: { username: string } }) {
  // In a real app, we would fetch user profile based on the username
  const profile = {
    username: params.username || "olec.jaeger",
    name: "olec jaeger",
    role: "filmmaker",
    location: "amsterdam, the netherlands",
    avatar: "/images/olec-jaeger.jpg",
    bio: "I'm a young and innovative filmmaker based in Amsterdam, driven by a passion for crafting compelling visuals that tell stories and create impact. I specialise in dynamic video production, delivering branding and commercial videos that resonate with audiences and elevate brands.",
    clients: [
      { name: "Sony", logo: "/images/client-logo-1.png" },
      { name: "NRC", logo: "/images/client-logo-2.png" },
      { name: "Nike", logo: "/images/client-logo-3.png" },
    ],
    skills: ["filmmaking", "photography", "premiere pro"],
  }

  return (
    <div className="pb-28">
      <div className="flex items-center justify-between p-4">
        <BackButton />
        <Logo />
        <div className="w-10"></div> {/* Spacer for alignment */}
      </div>

      <div className="px-6 pt-8">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h1 className="text-4xl font-bold mb-1">{profile.name}</h1>
            <p className="text-xl text-foreground">{profile.role}</p>
          </div>
          <div className="h-20 w-20 rounded-full overflow-hidden">
            <Image
              src={profile.avatar || "/placeholder.svg"}
              alt={profile.name}
              width={200}
              height={200}
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        <div className="flex items-center gap-2 mb-8">
          <span className="material-symbols-outlined text-muted-foreground">location_on</span>
          <span className="text-lg">{profile.location}</span>
          <div className="ml-auto">
            <span className="material-symbols-outlined">share</span>
          </div>
        </div>

        <div className="border-b mb-8">
          <div className="flex justify-between">
            <Link href={`/profile/${profile.username}/work`} className="text-xl pb-4 px-4 text-muted-foreground">
              work
            </Link>
            <Link
              href={`/profile/${profile.username}/about`}
              className="text-xl pb-4 px-4 border-b-2 border-foreground font-medium"
            >
              about
            </Link>
            <Link href={`/profile/${profile.username}/contact`} className="text-xl pb-4 px-4 text-muted-foreground">
              contact
            </Link>
          </div>
        </div>

        <div className="space-y-8">
          <div>
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-medium mb-4">about me</h2>
              <button className="text-muted-foreground">
                <span className="material-symbols-outlined">edit</span>
              </button>
            </div>
            <p className="text-lg leading-relaxed">{profile.bio}</p>
          </div>

          <div>
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-medium mb-4">clients</h2>
              <button className="text-muted-foreground">
                <span className="material-symbols-outlined">edit</span>
              </button>
            </div>
            <div className="flex flex-wrap gap-4">
              {profile.clients.map((client, index) => (
                <div key={index} className="flex items-center gap-2 bg-secondary rounded-full px-4 py-2">
                  <div className="w-8 h-8 rounded-full overflow-hidden bg-white flex items-center justify-center">
                    <Image
                      src={client.logo || "/placeholder.svg"}
                      alt={client.name}
                      width={40}
                      height={40}
                      className="w-6 h-6 object-contain"
                    />
                  </div>
                  <span>{client.name.toLowerCase()}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-medium mb-4">skills</h2>
              <button className="text-muted-foreground">
                <span className="material-symbols-outlined">edit</span>
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {profile.skills.map((skill, index) => (
                <div key={index} className="bg-secondary rounded-full px-4 py-2">
                  {skill}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <BottomNavigation />
    </div>
  )
}

