import { redirect } from "next/navigation"

export default function ProfilePage() {
  // Redirect to the work tab by default
  redirect("/profile/daiki.shino/work")
}

