"use client"

import Image from "next/image"
import Link from "next/link"
import BackButton from "@/components/back-button"
import Logo from "@/components/logo"
import BottomNavigation from "@/components/bottom-navigation"

export default function ProfileWorkPage() {
  // Profile data
  const profile = {
    username: "bibi.jane",
    name: "bibi-jane angelica",
    role: "mixed media editor",
    location: "amsterdam, the netherlands",
    avatar: "/images/bibi-jane.jpg",
    works: [
      {
        id: "1",
        title: "fashion week",
        role: "editor",
        image: "/images/job-image-7.jpg",
      },
      {
        id: "2",
        title: "brand campaign",
        role: "editor",
        image: "/images/job-image-8.jpg",
      },
      {
        id: "3",
        title: "music video",
        role: "editor",
        image: "/images/job-cover-1.jpg",
      },
      {
        id: "4",
        title: "commercial spot",
        role: "editor",
        image: "/images/job-cover-2.jpg",
      },
    ],
  }

  return (
    <div className="pb-28">
      <div className="flex items-center justify-between p-4">
        <BackButton />
        <Logo />
        <div className="w-10"></div> {/* Spacer for alignment */}
      </div>

      <div className="px-6 pt-8">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h1 className="text-4xl font-bold mb-1">{profile.name}</h1>
            <p className="text-xl text-foreground">{profile.role}</p>
          </div>
          <div className="h-20 w-20 rounded-full overflow-hidden">
            <Image
              src={profile.avatar || "/placeholder.svg"}
              alt={profile.name}
              width={200}
              height={200}
              className="w-full h-full object-cover"
              priority
            />
          </div>
        </div>

        <div className="flex items-center gap-2 mb-8">
          <span className="material-symbols-outlined text-muted-foreground">location_on</span>
          <span className="text-lg">{profile.location}</span>
          <div className="ml-auto">
            <span className="material-symbols-outlined">share</span>
          </div>
        </div>

        <div className="border-b mb-8">
          <div className="flex justify-between">
            <Link
              href={`/profile/${profile.username}/work`}
              className="text-xl pb-4 px-4 border-b-2 border-foreground font-medium"
            >
              work
            </Link>
            <Link href={`/profile/${profile.username}/about`} className="text-xl pb-4 px-4 text-muted-foreground">
              about
            </Link>
            <Link href={`/profile/${profile.username}/contact`} className="text-xl pb-4 px-4 text-muted-foreground">
              contact
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {profile.works.map((work) => (
            <div key={work.id} className="mb-6">
              <div className="rounded-lg overflow-hidden mb-2">
                <Image
                  src={work.image || "/placeholder.svg"}
                  alt={work.title}
                  width={300}
                  height={200}
                  className="w-full h-40 object-cover"
                />
              </div>
              <h3 className="font-medium text-lg">{work.title}</h3>
              <p className="text-muted-foreground">{work.role}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="fixed bottom-24 right-6">
        <button className="bg-black text-white rounded-full w-14 h-14 flex items-center justify-center shadow-lg">
          <span className="text-3xl">+</span>
        </button>
      </div>

      <BottomNavigation />
    </div>
  )
}

