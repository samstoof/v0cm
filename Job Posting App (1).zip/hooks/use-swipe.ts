"use client"

import { useState, useEffect, type TouchEvent } from "react"
import { useRouter } from "next/navigation"

interface SwipeProps {
  threshold?: number
  onSwipeLeft?: () => void
  onSwipeRight?: () => void
}

export function useSwipe({ threshold = 100, onSwipeLeft, onSwipeRight }: SwipeProps = {}) {
  const router = useRouter()
  const [touchStart, setTouchStart] = useState<number | null>(null)
  const [touchEnd, setTouchEnd] = useState<number | null>(null)
  const [swiping, setSwiping] = useState(false)
  const [swipeDistance, setSwipeDistance] = useState(0)

  // Reset values on unmount
  useEffect(() => {
    return () => {
      setTouchStart(null)
      setTouchEnd(null)
      setSwiping(false)
      setSwipeDistance(0)
    }
  }, [])

  const onTouchStart = (e: TouchEvent) => {
    setTouchEnd(null)
    setTouchStart(e.targetTouches[0].clientX)
    setSwiping(false)
    setSwipeDistance(0)
  }

  const onTouchMove = (e: TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX)

    if (touchStart) {
      const distance = touchStart - e.targetTouches[0].clientX
      setSwipeDistance(-distance) // Negative for right swipe
      setSwiping(true)
    }
  }

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return

    const distance = touchStart - touchEnd
    const isLeftSwipe = distance > threshold
    const isRightSwipe = distance < -threshold

    if (isLeftSwipe && onSwipeLeft) {
      onSwipeLeft()
    }

    if (isRightSwipe) {
      onSwipeRight ? onSwipeRight() : router.back()
    }

    // Reset swipe state
    setSwiping(false)
    setSwipeDistance(0)
  }

  return {
    onTouchStart,
    onTouchMove,
    onTouchEnd,
    swiping,
    swipeDistance,
  }
}

