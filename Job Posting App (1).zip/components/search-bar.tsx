"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface SearchBarProps {
  onSearch: (query: string) => void
}

export default function SearchBar({ onSearch }: SearchBarProps) {
  const [isExpanded, setIsExpanded] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  const handleToggleSearch = () => {
    setIsExpanded(!isExpanded)
    if (isExpanded && searchQuery) {
      onSearch("")
      setSearchQuery("")
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    onSearch(searchQuery)
  }

  return (
    <div className="flex items-center">
      {isExpanded ? (
        <form onSubmit={handleSearch} className="flex items-center gap-2">
          <Input
            type="text"
            placeholder="search jobs..."
            className="rounded-full h-12"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            autoFocus
          />
          <Button type="button" variant="outline" className="rounded-full p-0 w-12 h-12" onClick={handleToggleSearch}>
            <span className="material-symbols-outlined">close</span>
          </Button>
        </form>
      ) : (
        <Button variant="outline" className="rounded-full p-0 w-12 h-12" onClick={handleToggleSearch}>
          <span className="material-symbols-outlined">search</span>
        </Button>
      )}
    </div>
  )
}

