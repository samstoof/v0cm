"use client"

import Image from "next/image"

interface WorkItemProps {
  id: string
  title: string
  role: string
  image: string
  selected?: boolean
  onSelect?: (id: string) => void
}

export default function WorkItem({ id, title, role, image, selected, onSelect }: WorkItemProps) {
  return (
    <div className="mb-4">
      <div className="relative rounded-lg overflow-hidden mb-2 cursor-pointer" onClick={() => onSelect && onSelect(id)}>
        <div className="h-40 w-full">
          <Image
            src={image || "/placeholder.svg"}
            alt={title}
            width={300}
            height={200}
            className="w-full h-full object-cover"
          />
        </div>
        <div
          className={`absolute top-2 right-2 w-8 h-8 rounded-full flex items-center justify-center ${
            selected ? "bg-black" : "bg-white"
          }`}
        >
          {selected && <span className="material-symbols-outlined text-white">check</span>}
        </div>
      </div>
      <h3 className="font-medium text-lg">{title}</h3>
      <p className="text-muted-foreground">{role}</p>
    </div>
  )
}

