import Link from "next/link"
import Image from "next/image"

interface JobCardProps {
  id: string
  avatar: string
  director: string
  postedTime: string
  role: string
  location: string
  date: string
  company?: string
  budget: string
}

export default function JobCard({
  id,
  avatar,
  director,
  postedTime,
  role,
  location,
  date,
  company,
  budget,
}: JobCardProps) {
  return (
    <Link href={`/jobs/${id}`} className="block">
      <div className="border rounded-3xl p-4">
        <div className="flex justify-between items-start mb-2">
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-full overflow-hidden">
              <Image
                src={avatar || "/placeholder.svg"}
                alt={director}
                width={80}
                height={80}
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="text-sm text-muted-foreground">director</div>
              <div className="font-medium">{director}</div>
            </div>
          </div>
          <div className="text-muted-foreground">
            <span className="material-symbols-outlined">north_east</span>
          </div>
        </div>

        <div className="mb-1">posted {postedTime}</div>

        <div className="mb-4">
          <span className="text-xl font-medium">{role}</span>
          <span className="text-xl text-muted-foreground"> needed in </span>
          <span className="text-xl font-medium">{company ? "" : location}</span>
          {company && <span className="text-xl font-medium">{company}</span>}
          <span className="text-xl text-muted-foreground"> on </span>
          <span className="text-xl font-medium">{date}</span>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-muted-foreground">location_on</span>
            <span>{location}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-muted-foreground">payments</span>
            <span>{budget}</span>
          </div>
        </div>
      </div>
    </Link>
  )
}

