"use client"

import type { ReactNode } from "react"
import { useSwipe } from "@/hooks/use-swipe"
import { motion } from "framer-motion"

interface SwipeContainerProps {
  children: ReactNode
  onSwipeRight?: () => void
}

export default function SwipeContainer({ children, onSwipeRight }: SwipeContainerProps) {
  const { onTouchStart, onTouchMove, onTouchEnd, swiping, swipeDistance } = useSwipe({
    onSwipeRight,
  })

  return (
    <motion.div
      className="min-h-screen relative overflow-hidden"
      {...{ onTouchStart, onTouchMove, onTouchEnd }}
      animate={{
        x: swiping ? swipeDistance : 0,
        opacity: swiping && swipeDistance > 0 ? 1 - swipeDistance / 300 : 1,
      }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      {swiping && swipeDistance > 50 && (
        <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400">
          <span className="material-symbols-outlined text-3xl">arrow_back</span>
        </div>
      )}
      {children}
    </motion.div>
  )
}

