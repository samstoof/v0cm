"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface TabButtonProps {
  active?: boolean
  onClick?: () => void
  children: React.ReactNode
}

export default function TabButton({ active, onClick, children }: TabButtonProps) {
  return (
    <Button
      variant={active ? "default" : "outline"}
      className={cn("rounded-full", active ? "bg-primary text-primary-foreground" : "")}
      onClick={onClick}
    >
      {children}
    </Button>
  )
}

