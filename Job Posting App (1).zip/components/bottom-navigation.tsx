"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

export default function BottomNavigation() {
  const pathname = usePathname()

  return (
    <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 w-full px-6 max-w-md z-10">
      <div className="bg-background border rounded-full shadow-lg py-3 px-6">
        <div className="flex justify-around items-center">
          <Link
            href="/"
            className={cn(
              "flex flex-col items-center gap-1",
              pathname === "/" ? "text-foreground" : "text-muted-foreground",
            )}
          >
            <span className="material-symbols-outlined">home</span>
            <span className="text-xs">home</span>
          </Link>
          <Link
            href="/my-jobs"
            className={cn(
              "flex flex-col items-center gap-1",
              pathname.includes("/my-jobs") ? "text-foreground" : "text-muted-foreground",
            )}
          >
            <span className="material-symbols-outlined">work</span>
            <span className="text-xs">my jobs</span>
          </Link>
          <Link
            href="/settings"
            className={cn(
              "flex flex-col items-center gap-1",
              pathname.includes("/settings") ? "text-foreground" : "text-muted-foreground",
            )}
          >
            <span className="material-symbols-outlined">settings</span>
            <span className="text-xs">settings</span>
          </Link>
        </div>
      </div>
    </div>
  )
}

