import Image from "next/image"
import Link from "next/link"

export default function Logo() {
  return (
    <div className="text-center py-4 border-b w-full">
      <Link href="/" className="inline-block">
        <div className="w-8 h-4 mx-auto">
          <Image
            src="/images/cm-logo.svg"
            alt="cm logo"
            width={880}
            height={345}
            className="w-full h-full object-contain"
            priority
          />
        </div>
      </Link>
    </div>
  )
}

